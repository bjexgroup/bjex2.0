$(function(){
    var ThemeColor = {
        //黑色调
        up: "#00AC8D",
        down: "#CF424E",
        bg: "#ffffff",
        grid: "#F3F7F9",
        cross: "#23283D",
        border: "#98B0C0",
        text: "#98B0C0",
        areatop: "rgba(71, 78, 112, 0.1)",
        areadown: "rgba(71, 78, 112, 0.02)",
        line: "#ffffff"
      };
      TradingView.onready(function() {
        var widget = (window.tvWidget = new TradingView.widget({
          // debug: true, // uncomment this line to see Library errors and warnings in the console
          fullscreen: true,
          symbol: "AAPL",
          interval: "D",
          container_id: "kline_container",

          //	BEWARE: no trailing slash is expected in feed URL
          datafeed: new Datafeeds.UDFCompatibleDatafeed(
            // "https://easy-mock.com/mock/5c18b40b29e94a194029f5e9/example_copy"
            "https://demo_feed.tradingview.com"
            // "192.168.2.99:6969"
          ),
          library_path:  "libs/tradingview/charting_library/",
          locale: LNG || "zh",

          disabled_features: ["use_localstorage_for_settings"],
          enabled_features: ["study_templates"],
          charts_storage_url: "http://saveload.tradingview.com",
          charts_storage_api_version: "1.1",
          client_id: "tradingview.com",
          user_id: "public_user_id",
        //   theme: getParameterByName("theme"),

          timezone: "Asia/Shanghai", //这个商品的交易所时区  支持格式详见 以下备注①
          minmov: 1, //最小波动
          minmov2: 0, //这是一个神奇的数字来格式化复杂情况下的价格  例子详见备注②
          interval: 30,
          session: "24x7", //商品交易时间
          has_intraday: true, // 如果设置为true则由datafeed直接提供的所有分辨率必须在intraday_multipliers数组中设定 。如果它为false，则当图表中的该商品处于活动状态时，日内分辨率的所有按钮将被禁用
          intraday_multipliers: ["1", "5", "15", "30", "60", "1D", "1W"],
          regular_session: "24x7",
          disabled_features: [
            "compare_symbol",
            "go_to_date",
            "header_chart_type",
            "header_compare",
            "header_interval_dialog_button",
            "header_resolutions",
            "header_screenshot",
            "header_symbol_search",
            "header_undo_redo",
            "header_saveload",
            "legend_context_menu",
            "show_hide_button_in_legend",
            "show_interval_dialog_on_key_press",
            "snapshot_trading_drawings",
            "symbol_info",
            "timeframes_toolbar",
            "use_localstorage_for_settings",
            "volume_force_overlay",
            //			"control_bar",
            "context_menus"
            //			"left_toolbar",
          ],
          enabled_features: [
            "dont_show_boolean_study_arguments",
            "hide_last_na_study_output",
            "move_logo_to_main_pane",
            "same_data_requery",
            "side_toolbar_in_fullscreen_mode",
            "disable_resolution_rebuild",
            "display_market_status",
            "pane_context_menu"
          ],
          studies_overrides: {
            "volume.volume.color.0": "#fc0012", //柱狀顔色
            "volume.volume.color.1": "#3fcfb4", //柱狀顔色
            "volume.volume.transparency": 55 //柱狀大小
          },
          overrides: {
            //fc0012
            volumePaneSize: "small",
            "scalesProperties.lineColor": ThemeColor.text,
            "scalesProperties.textColor": ThemeColor.text,
            "paneProperties.background": ThemeColor.bg, //背景
            "paneProperties.vertGridProperties.color": ThemeColor.line, //纵向线
            "paneProperties.horzGridProperties.color": ThemeColor.line, //横向线
            "paneProperties.horzGridProperties.style": 0,
            "paneProperties.crossHairProperties.color": ThemeColor.cross, //鼠标放上去显示的线条颜色
            "paneProperties.crossHairProperties.style": 2, //鼠标放上去虚线
            "mainSeriesProperties.style": 8, //显示样式： K线、美国线、基准线...
            "mainSeriesProperties.showCountdown": false,
            "scalesProperties.showSeriesLastValue": true,
            "mainSeriesProperties.visible": true,
            "mainSeriesProperties.showPriceLine": true, //价格线
            "mainSeriesProperties.priceLineWidth": 1,
            "mainSeriesProperties.lockScale": false,
            "mainSeriesProperties.minTick": "default",
            "mainSeriesProperties.extendedHours": false,
            editorFontsList: [
              "Lato",
              "Arial",
              "Verdana",
              "Courier New",
              "Times New Roman"
            ],
            "paneProperties.topMargin": 5, //百分比例
            "paneProperties.bottomMargin": 5, //百分比例
            "timeScale.barSpacing": 6,

            "paneProperties.leftAxisProperties.autoScale": true,
            "paneProperties.leftAxisProperties.autoScaleDisabled": false,
            "paneProperties.leftAxisProperties.percentage": false,
            "paneProperties.leftAxisProperties.percentageDisabled": false,
            "paneProperties.leftAxisProperties.log": false,
            "paneProperties.leftAxisProperties.logDisabled": false,
            "paneProperties.leftAxisProperties.alignLabels": true,

            "paneProperties.legendProperties.showStudyArguments": true, //'close'
            "paneProperties.legendProperties.showStudyTitles": true,
            "paneProperties.legendProperties.showStudyValues": true,
            "paneProperties.legendProperties.showSeriesTitle": true,
            "paneProperties.legendProperties.showSeriesOHLC": true,
            //左右的轴线
            "scalesProperties.showLeftScale": false,
            "scalesProperties.showRightScale": true,

            "scalesProperties.backgroundColor": ThemeColor.text,
            "scalesProperties.lineColor": ThemeColor.text, //折线和蜡烛图分界线
            "scalesProperties.textColor": ThemeColor.text, //纵向、横向、标题颜色
            "scalesProperties.scaleSeriesOnly": false,
            "mainSeriesProperties.priceAxisProperties.autoScale": true,
            "mainSeriesProperties.priceAxisProperties.autoScaleDisabled": false,
            "mainSeriesProperties.priceAxisProperties.percentage": false,
            "mainSeriesProperties.priceAxisProperties.percentageDisabled": false,
            "mainSeriesProperties.priceAxisProperties.log": false,
            "mainSeriesProperties.priceAxisProperties.logDisabled": false,
            //蜡烛图
            "mainSeriesProperties.candleStyle.upColor": ThemeColor.up, //上升柱
            "mainSeriesProperties.candleStyle.downColor": ThemeColor.down, //下降柱
            "mainSeriesProperties.candleStyle.drawWick": false,
            "mainSeriesProperties.candleStyle.drawBorder": false,
            "mainSeriesProperties.candleStyle.borderColor": ThemeColor.line,
            "mainSeriesProperties.candleStyle.borderUpColor": ThemeColor.up,
            "mainSeriesProperties.candleStyle.borderDownColor": ThemeColor.down,
            "mainSeriesProperties.candleStyle.wickUpColor": ThemeColor.up,
            "mainSeriesProperties.candleStyle.wickDownColor": ThemeColor.down,
            "mainSeriesProperties.candleStyle.barColorsOnPrevClose": false,

            "mainSeriesProperties.hollowCandleStyle.upColor": ThemeColor.up,
            "mainSeriesProperties.hollowCandleStyle.downColor": ThemeColor.down,
            "mainSeriesProperties.hollowCandleStyle.drawWick": true,
            "mainSeriesProperties.hollowCandleStyle.drawBorder": true,
            "mainSeriesProperties.hollowCandleStyle.borderColor":
              ThemeColor.down,
            "mainSeriesProperties.hollowCandleStyle.borderUpColor":
              ThemeColor.up,
            "mainSeriesProperties.hollowCandleStyle.borderDownColor":
              ThemeColor.down,
            "mainSeriesProperties.hollowCandleStyle.wickColor": ThemeColor.line,
            "mainSeriesProperties.hollowCandleStyle.wickUpColor": ThemeColor.up,
            "mainSeriesProperties.hollowCandleStyle.wickDownColor":
              ThemeColor.down,

            "mainSeriesProperties.haStyle.upColor": ThemeColor.up,
            "mainSeriesProperties.haStyle.downColor": ThemeColor.down,
            "mainSeriesProperties.haStyle.drawWick": true,
            "mainSeriesProperties.haStyle.drawBorder": true,
            "mainSeriesProperties.haStyle.borderColor": ThemeColor.border,
            "mainSeriesProperties.haStyle.borderUpColor": ThemeColor.up,
            "mainSeriesProperties.haStyle.borderDownColor": ThemeColor.down,
            "mainSeriesProperties.haStyle.wickColor": ThemeColor.border,
            "mainSeriesProperties.haStyle.wickUpColor": ThemeColor.up,
            "mainSeriesProperties.haStyle.wickDownColor": ThemeColor.down,
            "mainSeriesProperties.haStyle.barColorsOnPrevClose": false,

            "mainSeriesProperties.barStyle.upColor": ThemeColor.up,
            "mainSeriesProperties.barStyle.downColor": ThemeColor.down,
            "mainSeriesProperties.barStyle.barColorsOnPrevClose": false,
            "mainSeriesProperties.barStyle.dontDrawOpen": false,

            "mainSeriesProperties.lineStyle.color": ThemeColor.border,
            "mainSeriesProperties.lineStyle.linestyle": 1,
            "mainSeriesProperties.lineStyle.priceSource": "close",

            "mainSeriesProperties.areaStyle.color1": ThemeColor.areatop,
            "mainSeriesProperties.areaStyle.color2": ThemeColor.areadown,
            "mainSeriesProperties.areaStyle.linecolor": ThemeColor.border,
            "mainSeriesProperties.areaStyle.linewidth": 1,
            "mainSeriesProperties.areaStyle.priceSource": "close",
            "scalesProperties.fontSize": 11, // 设置坐标轴字体大小
            "paneProperties.legendProperties.showLegend": false // 隐藏左上角标题
          },
          custom_css_url: "css/kline.css" //自定義css  路徑
        }));

        widget.onChartReady(function() {
          //结构配置
          var chart = widget.chart();
          widget.onShortcut("alt+s", function(a) {
            //截图快捷键
          });
          chart.executeActionById("drawingToolbarAction"); //默認收縮左边工具栏

          //设置折线
          var MALine5 = chart.createStudy(
            "Moving Average",
            false,
            false,
            [5],
            null,
            {
              "Plot.color": "rgb(150, 95, 196)"
            }
          );
          var MALine10 = chart.createStudy(
            "Moving Average",
            false,
            false,
            [10],
            null,
            {
              "Plot.color": "rgb(132, 170, 213)"
            }
          );
          var MALine30 = chart.createStudy(
            "Moving Average",
            false,
            false,
            [30],
            null,
            {
              "Plot.color": "rgb(85, 178, 99)"
            }
          );
          var MALine60 = chart.createStudy(
            "Moving Average",
            false,
            false,
            [60],
            null,
            {
              "Plot.color": "rgb(183, 36, 138)"
            }
          );
          //隐藏折线
          chart.getStudyById(MALine5).setVisible(true);
          chart.getStudyById(MALine10).setVisible(true);
          chart.getStudyById(MALine30).setVisible(true);
          chart.getStudyById(MALine60).setVisible(true);
          // 头部 添加按钮

          chart.onIntervalChanged().subscribe(null, function(interval, obj) {
            widget.changingInterval = false;
          });

          //widget.activeChart().resetData();//刷新

           
      //循环生成按钮绑定点击
      var myButon = []

      /*widget.createButton().append("<span>分时</span>").click(function(){
          widget.chart().setChartType(3)
      })
      .css({'background-color':'#262c38','color':'#4e5b85','border':'0'})
      .hover(function(){
          $(this).css({'background-color':'#4e5b85','color':'white'})
      },function(){
          $(this).css({'background-color':'#262c38','color':'#4e5b85'})
      })*/

      for(var i = 0;i<timeArry.length;i++)
      {
          (function(mytime){
              myButon[i] = widget.createButton()
                  .attr({'title':timeTitle[i]})
                  .on('click',function(){
                      clickTime = mytime
                      widget.setSymbol(Symbol, mytime)
                      widget.chart().setChartType(1)
                      clickBtn()
                      $(this).css({'background-color':'#4e5b85','color':'white'})
                  })
                  .append("<span>"+timeTitle[i]+"</span>")
                  .css({'background-color':(mytime==time)?'#4e5b85':'#262c38','border':'0','color':(mytime==time)?'white':'#4e5b85'})
                  .hover(function(){
                      if(clickTime!=mytime){
                          $(this).css({'background-color':'#4e5b85','color':'white'})
                      }
                  },function(){
                      if(clickTime!=mytime){
                          $(this).css({'background-color':'#262c38','color':'#4e5b85'})
                      }
                  })
          })(timeArry[i])
      }
      //重置所有btn样式
      function clickBtn()
      {
          for (var i = 0;i < myButon.length;i++) {
          myButon[i].css({'background-color':'#262c38','border':'0','color':'#4e5b85'})
          }
      }
  });


          //柱状图分布大小
          //var fromTime = bars[bars.length - 50].time / 1000;
          //var toTime = bars[bars.length - 1].time / 1000;
          //widget.chart().setVisibleRange({from: fromTime, to: toTime});
        })
      
})