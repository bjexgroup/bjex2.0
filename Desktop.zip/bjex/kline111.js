$(function(){
function getParameterByName(name) {
	name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
	var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
		results = regex.exec(location.search);
	return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
/*-------------------------------------------------------------------------------------------------*/


/*-------------------------------------------------------------------------------------------------*/
//配置jsApi方法
var config = {
	"supports_marks": false, //布尔值来标识 datafeed 是否支持在K线上显示标记
	"supports_timescale_marks": false, //布尔值来标识 datafeed 是否支持时间刻度标记
	"supports_time": false, //将此设置为true，假如datafeed提供服务器时间（unix时间）。 它用于调整时间刻度上的价格比例。
	"exchanges": [ //交易所
	],
	"symbols_types": [ //一个商品类型过滤器数组。该商品类型过滤器是个对象{name, value}

	],
	//左上角选择时间由此定义
	"supported_resolutions": ["1", "5", "15", '30', '60', '1D', '1W'] //一个表示服务器支持的分辨率数组，分辨率可以是数字或字符串。 如果分辨率是一个数字，它被视为分钟数
};
/****------------------------------------------************/
//全局变量

var bars = [];
var last_price = 10;
var globalInterval = 30;
// var klineUrls = baseLinkTwo +"/klineHistory";  
// var klineUrls ="http://192.168.2.211:6969/klineHistory";  
// var klineUrls = "http://192.168.2.189:8080/bjex-front/Kline/history";  
var exchanges = [];
var Datafeeds = {
	onReady: function (callback) { //提供填充配置数据的对象
		setTimeout(function () { //会出现个警告,我也不知道为什么
			callback(config);
		}, 0);
	},
	resolveSymbol: function (symbolName, onSymbolResolvedCallback, onResolveErrorCallback) { //通过商品名称解析商品信息(SymbolInfo)
		var symbol_stub = { //商品信息结构
			"name": market, //商品名称
			"timezone": "Asia/Shanghai", //这个商品的交易所时区  支持格式详见 以下备注①
			"pricescale": 1000000, //adjustScale()   价格精度    PriceScale 参数确定了图表价格量表上的价格线之间的间隔
			//minmov(最小波动), pricescale(价格精度), minmove2, fractional(分数) //最小的价格变化是由这些值决定的
			"minmov": 1, //最小波动
			"minmov2": 0, //这是一个神奇的数字来格式化复杂情况下的价格  例子详见备注②
			"fractional": "", //分数价格   1 - xx'yy（例如，133'21)或 2 - xx'yy'zz （例如，133'21'5）
			"interval": globalInterval,
			// onSymbolResolvedCallback(symbol_stub);
			//请一定指定ticker，如果没有ticker可以将symbol赋值给ticker，未指定ticker时会发生错误
			//ticker如果未明确指定，则被视为等于symbol
			"ticker": marketStr, //商品体系中此商品的唯一标识符
			"description": "", //商品说明
			"session": "24x7", //商品交易时间
			"exchange": "", //某个交易所的略称。将被显示在图表的图例中，以表示此商品
			"listed_exchange": "", //某个交易所的略称。将被显示在图表的图例中，以表示此商品
			"type": "stock", //可选类型  可选值：stock, index, forex, futures, bitcoin, expression, spread, cfd 或其他字符串
			"exchange-traded": "",
			"exchange-listed": "",
			"volume_precision": 2,
			"has_intraday": true, // 如果设置为true则由datafeed直接提供的所有分辨率必须在intraday_multipliers数组中设定 。如果它为false，则当图表中的该商品处于活动状态时，日内分辨率的所有按钮将被禁用
			"intraday_multipliers": config.supported_resolutions, //这是一个包含日内分辨率(分钟单位)的数组，datafeed将会自行构建它。
			//举例来说：如果datafeed报告说它支持 ["1", "5", "15"]，但事实上股票X只有1分钟的数据，股票X将设定 intraday_multipliers = [1]，那么Charting Library将自行构建5分钟和15分钟的分辨率。
			"has_weekly_and_monthly": true,
			"data_status": 'streaming',
			"regular_session": "24x7",
			//"expired":true,         //期满，布尔值显示此商品是否为到期的期货合约。
			//"expiration_date":'',   //到期日(Unix时间戳)。 如果expired = true，则必须设置此值。 图表库将从该时间点而不是实际时刻请求该商品的数据。
			//"data_status":"",       //数据状态码    支持的值:streaming(实时)、endofday(已收盘)、pulsed(脉冲)、delayed_streaming(延迟流动中)
			//"sector":"",            //板块，将在股票信息中显示。
			//"industry":"",          //行业，将在股票信息中显示。
			//"currency_code":"",     //货币代码，将在商品信息中显示。
		};
		setTimeout(function () {
			onSymbolResolvedCallback(symbol_stub);
		}, 0);
	},
	//通过日期范围获取历史K线数据。图表库希望通过onHistoryCallback仅一次调用，接收所有的请求历史。而不是被多次调用。
	getBars: function (symbolInfo, resolution, from, to, onHistoryCallback, onErrorCallback, firstDataRequest) {
		var _resolution = resolution;
		if (_resolution.indexOf('D') != -1) {
			_resolution = 1440;
		} else if (_resolution.indexOf('W') != -1) {
			_resolution = 10080;
		} else if (_resolution.indexOf('M') != -1) {
			_resolution = 43200;
		}
		window.localStorage.setItem('resolution',_resolution);
		var params = {
			market : market||"1",
			step : _resolution*60,
		};
		//best
		if (firstDataRequest) {
			$.ajax({
				type: "get",
				url: klineUrls,
				data: params,
				dataType: 'json',
				async:false,
				success: function (datas) {
					bars = [];
					if (datas) {
						var len = datas.length;
						var barValue = {};
						var objs = [];
						for (var i = 0; i < len; ++i) {  //去重准备  反向存储数据
							objs.push(datas[i][0]);
						}
						var adata = unique(objs);
						var lens = adata.length;
						for (var i = 0; i < lens; ++i) {
							if (adata[i] == datas[i][0]) {   //判读重复数据
								barValue = {
									time: Number(datas[i][0])*1000, //时间
									close: Number(datas[i][4]), //收盘
									open: Number(datas[i][3]), //开盘
									high: Number(datas[i][5]), //高度
									low: Number(datas[i][6]), //低度
									volume: Number(datas[i][7]), //数量
								}
								// if(i == lens-1){
                                //     window.localStorage.setItem('kcoin',symbolInfo.name);
                                //     window.localStorage.setItem('oldtime',Number(adata[i]));
                                //     window.localStorage.setItem('klastTime',Number(adata[i])/1000);
                                // }
								
							} else {
								datas.splice(i, 1);
							}
							bars.push(barValue);
						}
						onHistoryCallback(bars, {
							noData: false
						});

					} else {
						onHistoryCallback(bars, {
							noData: true
						})
					}
				},
				error: function (error) {
					console.log(error);

				}
			})
		} else {
			bars = [];
			onHistoryCallback(bars, {
				noData: true
			});
			return;
		}
	},
	//图表库在它要请求一些历史数据的时候会调用这个函数，让你能够覆盖所需的历史深度
	calculateHistoryDepth: function (resolution, resolutionBack, intervalBack) {

		var _resolution = resolution;
		if (_resolution.indexOf('D') != -1) {
			_resolution = 1440;
		} else if (_resolution.indexOf('W') != -1) {
			_resolution = 10080;
		} else if (_resolution.indexOf('M') != -1) {
			_resolution = 43200;
		}
		globalInterval = parseInt(_resolution);
		return undefined;
	},
	//订阅K线数据
	subscribeBars: function (symbolInfo, resolution, onRealtimeCallback, subscribeUID, onResetCacheNeededCallback) {
		stream.subscribeBars(symbolInfo, resolution, onRealtimeCallback, subscribeUID, onResetCacheNeededCallback);
	},
	//取消订阅K线数据
	unsubscribeBars: function (subscriberUID) {
		stream.unsubscribeBars(subscriberUID)
	},
	//图书馆调用这个函数来获得可见的K线范围的标记。 图表预期每调用一次getMarks就会调用一次onDataCallback。
	getMarks: function (symbolInfo, startDate, endDate, onDataCallback, resolution) {
		//optional
	},
	//图表库调用此函数获取可见K线范围的时间刻度标记。图表预期您每个调用getTimescaleMarks会调用一次onDataCallback。
	getTimescaleMarks: function (symbolInfo, startDate, endDate, onDataCallback, resolution) {
		//optional
	},
	//当图表需要知道服务器时间时，如果配置标志supports_time设置为true，则调用此函数
	getServerTime: function (cb) {

	}
}

/*-------------------------------------------------------------------------------------------------*/
var ThemeColor = { //黑色调
	up: "#00AC8D",
	down: "#CF424E",
	bg: "#ffffff",
	grid: "#F3F7F9",
	cross: "#23283D",
	border: "#98B0C0",
	text: "#98B0C0",
	areatop: "rgba(71, 78, 112, 0.1)",
	areadown: "rgba(71, 78, 112, 0.02)",
	line: "#ffffff",
}
TradingView.onready(function () { //初始化
	var widget = window.tvWidget = new TradingView.widget({
		fullscreen: false,
		symbol: "1",
		// symbol: sign,  //这个被我注释了的 嗯   step  s 是小写  makert 3 没有数据  后台好像没做处理  1 就有
		interval: globalInterval,
		toolbar_bg: "#ffffff",
		timezone: "Asia/Shanghai", //这个商品的交易所时区  支持格式详见 以下备注①
		container_id: "kline_container",
		datafeed: Datafeeds,
		allow_symbol_change: true,
		width: '100%',
		height: "469px",
		autosize: false,
		library_path: "libs/tradingview/charting_library/",   
		locale: LNG || "en",  //語言包
		drawings_access: {
			type: 'black',
			tools: [{
				name: "Regression Trend"
			}]
		},
		has_empty_bars: true,
		disabled_features: [
			"compare_symbol",
			"go_to_date",
			"header_chart_type",
			"header_compare",
			"header_interval_dialog_button",
			"header_resolutions",
			"header_screenshot",
			"header_symbol_search",
			"header_undo_redo",
			"header_saveload",
			"legend_context_menu",
			"show_hide_button_in_legend",
			"show_interval_dialog_on_key_press",
			"snapshot_trading_drawings",
			"symbol_info",
			"timeframes_toolbar",
			"use_localstorage_for_settings",
			"volume_force_overlay",
			//			"control_bar",
			"context_menus",
			//			"left_toolbar",
		],
		enabled_features: [
			"dont_show_boolean_study_arguments",
			"hide_last_na_study_output",
			"move_logo_to_main_pane",
			"same_data_requery",
			"side_toolbar_in_fullscreen_mode",
			"disable_resolution_rebuild",
			"display_market_status",
			"pane_context_menu",

		],
		//		charts_storage_url: 'http://saveload.tradingview.com',
		charts_storage_api_version: "1.12",  //版本
		client_id: 'tradingview.com',
		user_id: 'public_user_id',
		//		timeframe: config.supported_resolutions,
		time_frames: [ //最底部左下角的时间选择列表
			//			{ text: "50y", resolution: "6M" },
			//			{ text: "3y", resolution: "W" },
			//			{ text: "8m", resolution: "D" },
			//			{ text: "2m", resolution: "D" },
			//			{ text: "1m", resolution: "60" },
			//			{ text: "1w", resolution: "30" },
			//			{ text: "7d", resolution: "30" },
			//			{ text: "5d", resolution: "10" },
			//			{ text: "3d", resolution: "10" },
			//			{ text: "2d", resolution: "5" },
			//			{ text: "1d", resolution: "5" }
		],
		studies_overrides: {
			"volume.volume.color.0": "#fc0012",  //柱狀顔色
			"volume.volume.color.1": "#3fcfb4",  //柱狀顔色
			"volume.volume.transparency": 55,     //柱狀大小
		},
		overrides: { //fc0012
			volumePaneSize: "small",
			"scalesProperties.lineColor": ThemeColor.text,
			"scalesProperties.textColor": ThemeColor.text,
			"paneProperties.background": ThemeColor.bg, //背景
			"paneProperties.vertGridProperties.color": ThemeColor.line, //纵向线
			"paneProperties.horzGridProperties.color": ThemeColor.line, //横向线
			"paneProperties.horzGridProperties.style": 0,
			"paneProperties.crossHairProperties.color": ThemeColor.cross, //鼠标放上去显示的线条颜色
			"paneProperties.crossHairProperties.style": 2, //鼠标放上去虚线
			"mainSeriesProperties.style": 8, //显示样式： K线、美国线、基准线...
			"mainSeriesProperties.showCountdown": false,
			"scalesProperties.showSeriesLastValue": true,
			"mainSeriesProperties.visible": true,
			"mainSeriesProperties.showPriceLine": true, //价格线
			"mainSeriesProperties.priceLineWidth": 1,
			"mainSeriesProperties.lockScale": false,
			"mainSeriesProperties.minTick": "default",
			"mainSeriesProperties.extendedHours": false,
			"editorFontsList": ["Lato", "Arial", "Verdana", "Courier New", "Times New Roman"],
			"paneProperties.topMargin": 5, //百分比例
			"paneProperties.bottomMargin": 5, //百分比例
			"timeScale.barSpacing": 6,

			"paneProperties.leftAxisProperties.autoScale": true,
			"paneProperties.leftAxisProperties.autoScaleDisabled": false,
			"paneProperties.leftAxisProperties.percentage": false,
			"paneProperties.leftAxisProperties.percentageDisabled": false,
			"paneProperties.leftAxisProperties.log": false,
			"paneProperties.leftAxisProperties.logDisabled": false,
			"paneProperties.leftAxisProperties.alignLabels": true,

			"paneProperties.legendProperties.showStudyArguments": true, //'close'
			"paneProperties.legendProperties.showStudyTitles": true,
			"paneProperties.legendProperties.showStudyValues": true,
			"paneProperties.legendProperties.showSeriesTitle": true,
			"paneProperties.legendProperties.showSeriesOHLC": true,
			//左右的轴线
			"scalesProperties.showLeftScale": false,
			"scalesProperties.showRightScale": true,

			"scalesProperties.backgroundColor": ThemeColor.text,
			"scalesProperties.lineColor": ThemeColor.text, //折线和蜡烛图分界线
			"scalesProperties.textColor": ThemeColor.text, //纵向、横向、标题颜色
			"scalesProperties.scaleSeriesOnly": false,
			"mainSeriesProperties.priceAxisProperties.autoScale": true,
			"mainSeriesProperties.priceAxisProperties.autoScaleDisabled": false,
			"mainSeriesProperties.priceAxisProperties.percentage": false,
			"mainSeriesProperties.priceAxisProperties.percentageDisabled": false,
			"mainSeriesProperties.priceAxisProperties.log": false,
			"mainSeriesProperties.priceAxisProperties.logDisabled": false,
			//蜡烛图
			"mainSeriesProperties.candleStyle.upColor": ThemeColor.up, //上升柱
			"mainSeriesProperties.candleStyle.downColor": ThemeColor.down, //下降柱
			"mainSeriesProperties.candleStyle.drawWick": false,
			"mainSeriesProperties.candleStyle.drawBorder": false,
			"mainSeriesProperties.candleStyle.borderColor": ThemeColor.line,
			"mainSeriesProperties.candleStyle.borderUpColor": ThemeColor.up,
			"mainSeriesProperties.candleStyle.borderDownColor": ThemeColor.down,
			"mainSeriesProperties.candleStyle.wickUpColor": ThemeColor.up,
			"mainSeriesProperties.candleStyle.wickDownColor": ThemeColor.down,
			"mainSeriesProperties.candleStyle.barColorsOnPrevClose": false,

			"mainSeriesProperties.hollowCandleStyle.upColor": ThemeColor.up,
			"mainSeriesProperties.hollowCandleStyle.downColor": ThemeColor.down,
			"mainSeriesProperties.hollowCandleStyle.drawWick": true,
			"mainSeriesProperties.hollowCandleStyle.drawBorder": true,
			"mainSeriesProperties.hollowCandleStyle.borderColor": ThemeColor.down,
			"mainSeriesProperties.hollowCandleStyle.borderUpColor": ThemeColor.up,
			"mainSeriesProperties.hollowCandleStyle.borderDownColor": ThemeColor.down,
			"mainSeriesProperties.hollowCandleStyle.wickColor": ThemeColor.line,
			"mainSeriesProperties.hollowCandleStyle.wickUpColor": ThemeColor.up,
			"mainSeriesProperties.hollowCandleStyle.wickDownColor": ThemeColor.down,

			"mainSeriesProperties.haStyle.upColor": ThemeColor.up,
			"mainSeriesProperties.haStyle.downColor": ThemeColor.down,
			"mainSeriesProperties.haStyle.drawWick": true,
			"mainSeriesProperties.haStyle.drawBorder": true,
			"mainSeriesProperties.haStyle.borderColor": ThemeColor.border,
			"mainSeriesProperties.haStyle.borderUpColor": ThemeColor.up,
			"mainSeriesProperties.haStyle.borderDownColor": ThemeColor.down,
			"mainSeriesProperties.haStyle.wickColor": ThemeColor.border,
			"mainSeriesProperties.haStyle.wickUpColor": ThemeColor.up,
			"mainSeriesProperties.haStyle.wickDownColor": ThemeColor.down,
			"mainSeriesProperties.haStyle.barColorsOnPrevClose": false,

			"mainSeriesProperties.barStyle.upColor": ThemeColor.up,
			"mainSeriesProperties.barStyle.downColor": ThemeColor.down,
			"mainSeriesProperties.barStyle.barColorsOnPrevClose": false,
			"mainSeriesProperties.barStyle.dontDrawOpen": false,

			"mainSeriesProperties.lineStyle.color": ThemeColor.border,
			"mainSeriesProperties.lineStyle.linestyle": 1,
			"mainSeriesProperties.lineStyle.priceSource": "close",

			"mainSeriesProperties.areaStyle.color1": ThemeColor.areatop,
			"mainSeriesProperties.areaStyle.color2": ThemeColor.areadown,
			"mainSeriesProperties.areaStyle.linecolor": ThemeColor.border,
			"mainSeriesProperties.areaStyle.linewidth": 1,
			"mainSeriesProperties.areaStyle.priceSource": "close",
			'scalesProperties.fontSize': 11, // 设置坐标轴字体大小
			'paneProperties.legendProperties.showLegend': false, // 隐藏左上角标题
		},
		//      favorites: {
		//			intervals: ["1D", "2D", "3W", "W", "M"],
		//			chartTypes: ["Area", "Line"]
		//		},
		custom_css_url: 'css/kline.css',  //自定義css  路徑
	});

	widget.onChartReady(function () { //结构配置
		var chart = widget.chart();
		widget.onShortcut("alt+s", function (a) { //截图快捷键

		});
		chart.executeActionById('drawingToolbarAction'); //默認收縮左边工具栏


		//设置折线
		var MALine5 = chart.createStudy('Moving Average', false, false, [5], null, {
			'Plot.color': 'rgb(150, 95, 196)'
		});
		var MALine10 = chart.createStudy('Moving Average', false, false, [10], null, {
			'Plot.color': 'rgb(132, 170, 213)'
		});
		var MALine30 = chart.createStudy('Moving Average', false, false, [30], null, {
			'Plot.color': 'rgb(85, 178, 99)'
		});
		var MALine60 = chart.createStudy('Moving Average', false, false, [60], null, {
			'Plot.color': 'rgb(183, 36, 138)'
		});
		//隐藏折线
		chart.getStudyById(MALine5).setVisible(true);
		chart.getStudyById(MALine10).setVisible(true);
		chart.getStudyById(MALine30).setVisible(true);
		chart.getStudyById(MALine60).setVisible(true);
		// 头部 添加按钮
		var btnList = [{
			slug: "分时",
			resolution: "1",
			chartType: 3,
		}, {
			slug: "1min",
			resolution: "1"
		}, {
			slug: "5min",
			resolution: "5"
		}, {
			slug: "15min",
			resolution: "15"
		}, {
			slug: "30min",
			resolution: "30"
		}, {
			slug: "1hour",
			resolution: "60",
		}, {
			slug: "1day",
			resolution: "1D",
		}, {
			slug: "1week",
			resolution: "1W",
		}, ];
		chart.onIntervalChanged().subscribe(null, function (interval, obj) {
			widget.changingInterval = false;
		});

		//widget.activeChart().resetData();//刷新

		btnList.forEach(function (item, index) {
			var button = widget.createButton({
				align: "left"
			});
			item.resolution === widget._options.interval && updateSelectedIntervalButton(button);
			button.attr('class', "button").attr('data-id', index).attr('title', item.slug).attr("data-chart-type", item.chartType === undefined ? 8 : item.chartType).on('click', function (e) {
				var chartType = +button.attr("data-chart-type");
				if (chart.resolution() !== item.resolution) {
					chart.setResolution(item.resolution);
				}
				if (chart.chartType() !== chartType) {
					if (chartType === 8) {
						chart.getStudyById(MALine5).setVisible(true);
						chart.getStudyById(MALine10).setVisible(true);
						chart.getStudyById(MALine30).setVisible(true);
						chart.getStudyById(MALine60).setVisible(true);
					} else {
						chart.getStudyById(MALine5).setVisible(false);
						chart.getStudyById(MALine10).setVisible(false);
						chart.getStudyById(MALine30).setVisible(false);
						chart.getStudyById(MALine60).setVisible(false);
					}
					chart.setChartType(chartType);
				} else {
					chart.getStudyById(MALine5).setVisible(true);
					chart.getStudyById(MALine10).setVisible(true);
					chart.getStudyById(MALine30).setVisible(true);
					chart.getStudyById(MALine60).setVisible(true);
				}
				updateSelectedIntervalButton(button);
			}).append('<span>' + item.slug + '</span>');
			if (index === 4) { //给第一个加属性
				button.attr('class', 'button selected firstbutton btn1');
			}

		});


		function updateSelectedIntervalButton(button) {
			if (button.attr('data-id') != 4) {
				button.parents('.layout__area--top').find('.firstbutton').removeClass('firstbutton selected');
			}
			widget.selectedIntervalButton && widget.selectedIntervalButton.removeClass("selected");
			button.addClass("selected");
			widget.selectedIntervalButton = button;
		}

         //柱状图分布大小
		//var fromTime = bars[bars.length - 50].time / 1000;
		//var toTime = bars[bars.length - 1].time / 1000;
		//widget.chart().setVisibleRange({from: fromTime, to: toTime});

	})

});


//订阅数据
var getData = null;
var _subs = [];
var stream = {
	subscribeBars: function (symbolInfo, resolution, onRealtimeCallback, subscribeUID, onResetCacheNeededCallback) {
		var newSub = {
			channelString: symbolInfo.name,
			subscribeUID: subscribeUID,
			resolution: resolution,
			lastBar: history[symbolInfo.name],
			listener: onRealtimeCallback,
		};

		var _res = resolution;
        if (resolution.indexOf('D') != -1) {
            _res = 1440;
        } else if (resolution.indexOf('W') != -1) {
            _res = 10080;
        } else if(resolution.indexOf('M') != -1){
            _res  =   43200;
		}
		
		if(getData != null){
			return ;
		}else{
			getData = setInterval(DataTime, 3000);
		}
		var dataList = {};
		// var newKlineUrl = baseLinkTwo +"/klineNew";  
		function DataTime() {
			var params = {
				market: market||"1",
				step : _res*60,
			};
			var _resolution = window.localStorage.getItem('resolution');
			if(_resolution){
				params.step = Number(_resolution)*60
			}
			// alert("11111111111")
			$.getJSON(newKlineUrl,params, function (data) {
				data=[[1544770201,0,0,555.00000000,555.00000000,555.00000000,555.00000000,1]];
				if (data.length && data[0][0]) {
					dataList = {
						time: Number(data[0][0])*1000, //时间
						close: Number(data[0][4]), //收盘
						open: Number(data[0][3]), //开盘
						high: Number(data[0][5]), //高度
						low: Number(data[0][6]), //低度
						volume: Number(data[0][7]), //数量
					}
					newSub.listener(dataList);
				} else {

				}

			})
			_subs.push(newSub);
		}
	},
	unsubscribeBars: function (uid) {
		var len = _subs.length;
		var subIndex = 0;
		// for (var i=0;i<len;i++) {
		// if (_subs[i].subscribeUID != uid) {
		// return;
		// }else{
		// _subs.splice(i, 1)
		// }
		// }
	}
};

//去除重复元素
function unique(arr) {
	var arrs = [];
	for (var i = 0; i < arr.length; i++) {
		if (arr.indexOf(arr[i]) == i) {
			arrs.push(arr[i]);
		}
	}
	return arrs;
}

/*************************************************************************************/






/**
 * 备注①：
 UTC
 America/New_York
 America/Los_Angeles
 America/Chicago
 America/Phoenix
 America/Toronto
 America/Vancouver
 America/Argentina/Buenos_Aires
 America/El_Salvador
 America/Sao_Paulo
 America/Bogota
 Europe/Moscow
 Europe/Athens
 Europe/Berlin
 Europe/London
 Europe/Madrid
 Europe/Paris
 Europe/Warsaw
 Australia/Sydney
 Australia/Brisbane
 Australia/Adelaide
 Australia/ACT
 Asia/Almaty
 Asia/Ashkhabad
 Asia/Tokyo
 Asia/Taipei
 Asia/Singapore
 Asia/Shanghai
 Asia/Seoul
 Asia/Tehran
 Asia/Dubai
 Asia/Kolkata
 Asia/Hong_Kong
 Asia/Bangkok
 Pacific/Auckland
 Pacific/Chatham
 Pacific/Fakaofo
 Pacific/Honolulu
 America/Mexico_City
 Africa/Johannesburg
 Asia/Kathmandu
 US/Mountain
 * ------------------------------*
 * 备注②：
 典型的股票以0.01价格增量：minmov = 1，pricecale = 100，minmove2 = 0
 ZBM2014（国债），1/32：minmov = 1，pricecale = 32，minmove2 = 0
 ZCM2014（玉米），2/8：minmov = 2，pricecale = 8，minmove2 = 0
 ZFM2014（5年期国债），1/32的1/4：minmov = 1，pricecale = 128，minmove2 = 4
 *
 * */
	
})